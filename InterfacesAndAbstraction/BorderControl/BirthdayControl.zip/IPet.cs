﻿namespace BorderControl
{
    public interface IPet : IBirthable
    {
        string Name { get; set; }
    }
}
