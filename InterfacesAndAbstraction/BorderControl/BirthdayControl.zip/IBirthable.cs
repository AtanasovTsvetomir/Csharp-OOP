﻿namespace BorderControl
{
    public interface IBirthable
    {
        string Birthday { get; set; }
    }
}
