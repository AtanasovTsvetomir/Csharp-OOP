﻿using MXGP.Core.Contracts;
using System;

namespace MXGP.Core
{
    public class Engine : IEngine
    {
        
        public void Run()
        {
          
        }
    }
}
