﻿using ShoppingSpree.Core;

namespace ShoppingSpree
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
