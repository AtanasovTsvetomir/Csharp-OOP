﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using MortalEngines.IO.Contracts;

namespace MortalEngines.IO
{
    public class ConsoleReader
    {
        
    }
}
