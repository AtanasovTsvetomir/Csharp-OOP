﻿using MortalEngines.IO.Contracts;

namespace MortalEngines.IO
{
    public class ConsoleWriter
    {
        
    }
}
