﻿using System;
using System.Collections.Generic;

using MortalEngines.Core.Contracts;
using MortalEngines.IO.Contracts;

namespace MortalEngines.IO
{
    public class Reader : IReader
    {
        //public IList<ICommand> ReadCommands()
        //{
        //    throw new NotImplementedException();
        //}
    }
}
